export function formatMoney(value: number, currency = "UZS") {
  const n = Math.round(Number(value) || 0);
  const formatted = new Intl.NumberFormat("ru-RU").format(n);
  const symbols: Record<string, string> = { UZS: "сум", USD: "$", RUB: "₽", KZT: "₸", EUR: "€" };
  const symbol = symbols[currency] ?? currency;
  return currency === "USD" || currency === "EUR" ? `${symbol}${formatted}` : `${formatted} ${symbol}`;
}

export function today() {
  return new Date().toISOString().slice(0, 10);
}

export function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "short" });
}

export function formatDateTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString("ru-RU", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function rangeStart(period: "today" | "week" | "month" | "year") {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  if (period === "week") d.setDate(d.getDate() - 6);
  if (period === "month") d.setDate(d.getDate() - 29);
  if (period === "year") d.setMonth(d.getMonth() - 11);
  return d.toISOString().slice(0, 10);
}
