import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Key } from "./i18n";

export type Customer = {
  id: string;
  name: string;
  phone: string | null;
  note: string | null;
  created_at: string;
  updated_at: string;
};

export type DebtEntry = {
  id: string;
  customer_id: string;
  kind: "debt" | "payment";
  amount: number;
  comment: string | null;
  entry_date: string;
  created_at: string;
};

export type FinanceEntry = {
  id: string;
  kind: "income" | "expense";
  amount: number;
  category: string;
  comment: string | null;
  entry_date: string;
  created_at: string;
};

export type Profile = {
  id: string;
  full_name: string | null;
  store_name: string;
  currency: string;
  language: string;
};

export const EXPENSE_CATEGORIES: { value: string; key: Key }[] = [
  { value: "purchase", key: "catPurchase" },
  { value: "rent", key: "catRent" },
  { value: "salary", key: "catSalary" },
  { value: "transport", key: "catTransport" },
  { value: "other", key: "catOther" },
];

export const INCOME_CATEGORIES: { value: string; key: Key }[] = [
  { value: "sales", key: "catSales" },
  { value: "service", key: "catService" },
  { value: "other", key: "catOther" },
];

export function useProfile() {
  return useQuery({
    queryKey: ["profile"],
    queryFn: async (): Promise<Profile | null> => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data, error } = await supabase.from("profiles").select("*").eq("id", auth.user.id).maybeSingle();
      if (error) throw error;
      if (!data) {
        const { data: created, error: e2 } = await supabase
          .from("profiles")
          .insert({ id: auth.user.id })
          .select()
          .single();
        if (e2) throw e2;
        return created as Profile;
      }
      return data as Profile;
    },
  });
}

export function useCustomers() {
  return useQuery({
    queryKey: ["customers"],
    queryFn: async (): Promise<Customer[]> => {
      const { data, error } = await supabase.from("customers").select("*").order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Customer[];
    },
  });
}

export function useDebtEntries() {
  return useQuery({
    queryKey: ["debt_entries"],
    queryFn: async (): Promise<DebtEntry[]> => {
      const { data, error } = await supabase
        .from("debt_entries")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((d) => ({ ...d, amount: Number(d.amount) })) as DebtEntry[];
    },
  });
}

export function useFinanceEntries() {
  return useQuery({
    queryKey: ["finance_entries"],
    queryFn: async (): Promise<FinanceEntry[]> => {
      const { data, error } = await supabase
        .from("finance_entries")
        .select("*")
        .order("entry_date", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((d) => ({ ...d, amount: Number(d.amount) })) as FinanceEntry[];
    },
  });
}

async function currentUserId() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Not authenticated");
  return data.user.id;
}

export function useSaveCustomer() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { id?: string; name: string; phone?: string | null; note?: string | null }) => {
      const user_id = await currentUserId();
      if (input.id) {
        const { error } = await supabase
          .from("customers")
          .update({ name: input.name, phone: input.phone ?? null, note: input.note ?? null })
          .eq("id", input.id);
        if (error) throw error;
        return input.id;
      }
      const { data, error } = await supabase
        .from("customers")
        .insert({ user_id, name: input.name, phone: input.phone ?? null, note: input.note ?? null })
        .select()
        .single();
      if (error) throw error;
      return data.id as string;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["customers"] }),
  });
}

export function useAddDebtEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      customer_id: string;
      kind: "debt" | "payment";
      amount: number;
      comment?: string | null;
      entry_date: string;
    }) => {
      const user_id = await currentUserId();
      const { error } = await supabase.from("debt_entries").insert({ ...input, user_id });
      if (error) throw error;
      await supabase.from("customers").update({ updated_at: new Date().toISOString() }).eq("id", input.customer_id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["debt_entries"] });
      qc.invalidateQueries({ queryKey: ["customers"] });
    },
  });
}

export function useAddFinanceEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      kind: "income" | "expense";
      amount: number;
      category: string;
      comment?: string | null;
      entry_date: string;
    }) => {
      const user_id = await currentUserId();
      const { error } = await supabase.from("finance_entries").insert({ ...input, user_id });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["finance_entries"] }),
  });
}

export function useDeleteEntry(table: "finance_entries" | "debt_entries" | "customers") {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from(table).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [table] });
      qc.invalidateQueries({ queryKey: ["debt_entries"] });
      qc.invalidateQueries({ queryKey: ["customers"] });
    },
  });
}

export function useUpdateProfile() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: Partial<Pick<Profile, "store_name" | "currency" | "full_name" | "language">>) => {
      const id = await currentUserId();
      const { error } = await supabase.from("profiles").update(input).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["profile"] }),
  });
}

export function balanceOf(entries: DebtEntry[], customerId: string) {
  return entries
    .filter((e) => e.customer_id === customerId)
    .reduce((sum, e) => sum + (e.kind === "debt" ? e.amount : -e.amount), 0);
}
