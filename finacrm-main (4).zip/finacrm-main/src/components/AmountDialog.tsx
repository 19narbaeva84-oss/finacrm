import { useEffect, useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useI18n, type Key } from "@/lib/i18n";
import { today } from "@/lib/format";
import { cn } from "@/lib/utils";

export type AmountFormValue = {
  amount: number;
  category: string;
  comment: string;
  entry_date: string;
};

export function AmountDialog({
  open,
  onOpenChange,
  title,
  tone = "success",
  categories,
  defaultCategory = "other",
  header,
  submitLabel,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  tone?: "success" | "danger";
  categories?: { value: string; key: Key }[];
  defaultCategory?: string;
  header?: ReactNode;
  submitLabel?: string;
  onSubmit: (value: AmountFormValue) => Promise<void> | void;
}) {
  const { t } = useI18n();
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState(defaultCategory);
  const [comment, setComment] = useState("");
  const [date, setDate] = useState(today());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setAmount("");
      setComment("");
      setCategory(defaultCategory);
      setDate(today());
    }
  }, [open, defaultCategory]);

  const submit = async () => {
    const value = Number(amount);
    if (!value || value <= 0) return;
    setBusy(true);
    try {
      await onSubmit({ amount: value, category, comment, entry_date: date });
      onOpenChange(false);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        {header}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">{t("amount")}</Label>
            <Input
              id="amount"
              inputMode="numeric"
              autoFocus
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
              placeholder="0"
              className={cn(
                "h-14 rounded-2xl text-2xl font-bold",
                tone === "success" ? "text-success" : "text-danger",
              )}
            />
          </div>

          {categories ? (
            <div className="space-y-2">
              <Label>{t("category")}</Label>
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setCategory(c.value)}
                    className={cn(
                      "rounded-full border px-3 py-2 text-sm font-medium transition-colors",
                      category === c.value
                        ? "border-transparent bg-primary text-primary-foreground"
                        : "bg-card hover:bg-accent",
                    )}
                  >
                    {t(c.key)}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          <div className="space-y-2">
            <Label htmlFor="date">{t("date")}</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-12 rounded-2xl"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="comment">
              {t("comment")} <span className="text-muted-foreground">({t("optional")})</span>
            </Label>
            <Textarea
              id="comment"
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="rounded-2xl"
            />
          </div>
        </div>
        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="ghost" className="h-12 rounded-2xl" onClick={() => onOpenChange(false)}>
            {t("cancel")}
          </Button>
          <Button
            className={cn(
              "h-12 flex-1 rounded-2xl text-base font-semibold",
              tone === "success"
                ? "bg-success text-success-foreground hover:bg-success/90"
                : "bg-danger text-danger-foreground hover:bg-danger/90",
            )}
            disabled={busy || !amount}
            onClick={submit}
          >
            {submitLabel ?? t("save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
