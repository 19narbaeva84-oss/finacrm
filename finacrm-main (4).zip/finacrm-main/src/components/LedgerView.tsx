import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { AmountDialog } from "@/components/AmountDialog";
import { EmptyState, StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n, type Key } from "@/lib/i18n";
import { formatMoney, formatDateTime } from "@/lib/format";
import {
  EXPENSE_CATEGORIES,
  INCOME_CATEGORIES,
  useAddFinanceEntry,
  useDeleteEntry,
  useFinanceEntries,
  useProfile,
  type FinanceEntry,
} from "@/lib/data";
import { cn } from "@/lib/utils";

const CATEGORY_KEYS: Record<string, Key> = {
  purchase: "catPurchase",
  rent: "catRent",
  salary: "catSalary",
  transport: "catTransport",
  sales: "catSales",
  service: "catService",
  other: "catOther",
};

export function LedgerView({ mode }: { mode: "finance" | "expenses" }) {
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: entries = [] } = useFinanceEntries();
  const add = useAddFinanceEntry();
  const remove = useDeleteEntry("finance_entries");
  const [dialog, setDialog] = useState<null | "income" | "expense">(null);
  const [toDelete, setToDelete] = useState<string | null>(null);

  const currency = profile?.currency ?? "UZS";
  const visible = mode === "expenses" ? entries.filter((e) => e.kind === "expense") : entries;

  const days = useMemo(() => {
    const map = new Map<string, FinanceEntry[]>();
    for (const e of visible) {
      const arr = map.get(e.entry_date) ?? [];
      arr.push(e);
      map.set(e.entry_date, arr);
    }
    return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [visible]);

  const totals = useMemo(() => {
    const income = entries.filter((e) => e.kind === "income").reduce((s, e) => s + e.amount, 0);
    const expense = entries.filter((e) => e.kind === "expense").reduce((s, e) => s + e.amount, 0);
    return { income, expense, profit: income - expense };
  }, [entries]);

  return (
    <div className="space-y-4">
      {mode === "finance" ? (
        <div className="grid grid-cols-3 gap-3">
          <StatCard label={t("incomeTotal")} value={formatMoney(totals.income, currency)} tone="success" />
          <StatCard label={t("expenseTotal")} value={formatMoney(totals.expense, currency)} tone="danger" />
          <StatCard
            label={t("profit")}
            value={formatMoney(totals.profit, currency)}
            tone={totals.profit >= 0 ? "success" : "danger"}
          />
        </div>
      ) : (
        <StatCard label={t("expenseTotal")} value={formatMoney(totals.expense, currency)} tone="danger" />
      )}

      <div className={cn("grid gap-3", mode === "finance" ? "grid-cols-2" : "grid-cols-1")}>
        {mode === "finance" ? (
          <Button
            className="h-14 rounded-2xl bg-success text-base font-semibold text-success-foreground hover:bg-success/90"
            onClick={() => setDialog("income")}
          >
            <Plus className="h-5 w-5" /> {t("addIncome")}
          </Button>
        ) : null}
        <Button
          className="h-14 rounded-2xl bg-danger text-base font-semibold text-danger-foreground hover:bg-danger/90"
          onClick={() => setDialog("expense")}
        >
          <Plus className="h-5 w-5" /> {t("addExpense")}
        </Button>
      </div>

      {days.length === 0 ? (
        <EmptyState title={t("noData")} hint={t("noDataHint")} />
      ) : (
        days.map(([date, items]) => {
          const dayIncome = items.filter((e) => e.kind === "income").reduce((s, e) => s + e.amount, 0);
          const dayExpense = items.filter((e) => e.kind === "expense").reduce((s, e) => s + e.amount, 0);
          return (
            <section key={date} className="overflow-hidden rounded-2xl border bg-card">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b px-4 py-3">
                <p className="truncate text-sm font-bold">
                  {new Date(date).toLocaleDateString("ru-RU", { day: "2-digit", month: "long" })}
                </p>
                <p className="shrink-0 text-sm font-bold">
                  {mode === "expenses" ? (
                    <span className="text-danger">{formatMoney(dayExpense, currency)}</span>
                  ) : (
                    <>
                      <span className="text-success">{formatMoney(dayIncome, currency)}</span>
                      <span className="text-muted-foreground"> / </span>
                      <span className="text-danger">{formatMoney(dayExpense, currency)}</span>
                    </>
                  )}
                </p>
              </div>
              <ul className="divide-y">
                {items.map((e) => (
                  <li key={e.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{t(CATEGORY_KEYS[e.category] ?? "catOther")}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {formatDateTime(e.created_at)}
                        {e.comment ? ` · ${e.comment}` : ""}
                      </p>
                    </div>
                    <span
                      className={cn("shrink-0 text-sm font-bold", e.kind === "income" ? "text-success" : "text-danger")}
                    >
                      {e.kind === "income" ? "+" : "−"}
                      {formatMoney(e.amount, currency)}
                    </span>
                    <button
                      onClick={() => setToDelete(e.id)}
                      className="shrink-0 text-muted-foreground hover:text-danger"
                      aria-label={t("delete")}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          );
        })
      )}

      <AmountDialog
        open={dialog !== null}
        onOpenChange={(v) => setDialog(v ? dialog : null)}
        title={dialog === "expense" ? t("addExpense") : t("addIncome")}
        tone={dialog === "expense" ? "danger" : "success"}
        categories={dialog === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES}
        defaultCategory={dialog === "expense" ? "purchase" : "sales"}
        onSubmit={async (v) => {
          await add.mutateAsync({ kind: dialog === "expense" ? "expense" : "income", ...v });
          toast.success(t("saved"));
        }}
      />

      <AlertDialog open={toDelete !== null} onOpenChange={(v) => !v && setToDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>{t("confirmDelete")}</AlertDialogTitle>
            <AlertDialogDescription>{t("confirmDeleteText")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-2xl">{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="rounded-2xl bg-danger text-danger-foreground hover:bg-danger/90"
              onClick={async () => {
                if (toDelete) await remove.mutateAsync(toDelete);
                setToDelete(null);
                toast.success(t("deleted"));
              }}
            >
              {t("delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
