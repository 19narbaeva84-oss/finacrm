import type { ReactNode } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Users,
  Wallet,
  Receipt,
  BarChart3,
  History,
  Settings,
  Moon,
  Sun,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n, type Key } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { useProfile } from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const NAV: { to: string; key: Key; icon: typeof Users }[] = [
  { to: "/dashboard", key: "dashboard", icon: LayoutDashboard },
  { to: "/debts", key: "debts", icon: Users },
  { to: "/finance", key: "finance", icon: Wallet },
  { to: "/expenses", key: "expenses", icon: Receipt },
  { to: "/analytics", key: "analytics", icon: BarChart3 },
  { to: "/history", key: "history", icon: History },
  { to: "/settings", key: "settings", icon: Settings },
];

const MOBILE_NAV = NAV.filter((n) => ["/dashboard", "/debts", "/finance", "/analytics", "/settings"].includes(n.to));

export function AppShell({ children }: { children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const { data: profile } = useProfile();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 hidden w-60 flex-col border-r bg-card p-4 lg:flex">
        <div className="px-2 py-3">
          <p className="text-lg font-extrabold tracking-tight">{profile?.store_name ?? t("appName")}</p>
          <p className="text-xs text-muted-foreground">{t("appName")}</p>
        </div>
        <nav className="mt-4 flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent",
                )}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{t(item.key)}</span>
              </Link>
            );
          })}
        </nav>
        <Button variant="ghost" className="justify-start gap-3 rounded-xl" onClick={signOut}>
          <LogOut className="h-4 w-4" /> {t("signOut")}
        </Button>
      </aside>

      <div className="lg:pl-60">
        <header className="sticky top-0 z-30 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b bg-background/85 px-4 py-3 backdrop-blur">
          <div className="min-w-0">
            <p className="truncate text-base font-extrabold tracking-tight">
              {profile?.store_name ?? t("appName")}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {NAV.find((n) => pathname.startsWith(n.to))?.key ? t(NAV.find((n) => pathname.startsWith(n.to))!.key) : ""}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <button
              onClick={() => setLang(lang === "ru" ? "uz" : "ru")}
              className="rounded-xl border px-3 py-2 text-xs font-bold uppercase"
            >
              {lang}
            </button>
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="grid h-9 w-9 place-items-center rounded-xl border"
              aria-label={t("theme")}
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-5xl px-4 pb-28 pt-4 lg:pb-10">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-card/95 backdrop-blur lg:hidden">
        {MOBILE_NAV.map((item) => {
          const active = pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium transition-colors",
                active ? "text-success" : "text-muted-foreground",
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="truncate px-0.5">{t(item.key)}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
