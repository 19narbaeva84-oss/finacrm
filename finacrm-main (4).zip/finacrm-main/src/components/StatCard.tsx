import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  icon,
  tone = "neutral",
  hint,
}: {
  label: string;
  value: string;
  icon?: ReactNode;
  tone?: "neutral" | "success" | "danger";
  hint?: string;
}) {
  return (
    <div className="rounded-2xl border bg-card p-4 shadow-[0_1px_2px_rgba(0,0,0,0.04)]">
      <div className="flex items-center gap-2">
        {icon ? (
          <span
            className={cn(
              "grid h-8 w-8 shrink-0 place-items-center rounded-xl",
              tone === "success" && "bg-success-soft text-success",
              tone === "danger" && "bg-danger-soft text-danger",
              tone === "neutral" && "bg-muted text-muted-foreground",
            )}
          >
            {icon}
          </span>
        ) : null}
        <p className="min-w-0 truncate text-xs font-medium text-muted-foreground">{label}</p>
      </div>
      <p
        className={cn(
          "mt-3 text-xl font-extrabold tracking-tight sm:text-2xl",
          tone === "success" && "text-success",
          tone === "danger" && "text-danger",
        )}
      >
        {value}
      </p>
      {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed bg-card px-6 py-12 text-center">
      <p className="text-base font-semibold">{title}</p>
      {hint ? <p className="mx-auto mt-1 max-w-xs text-sm text-muted-foreground">{hint}</p> : null}
      {action ? <div className="mt-5 flex justify-center">{action}</div> : null}
    </div>
  );
}
