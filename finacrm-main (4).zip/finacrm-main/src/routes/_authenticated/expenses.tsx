import { createFileRoute } from "@tanstack/react-router";
import { LedgerView } from "@/components/LedgerView";

export const Route = createFileRoute("/_authenticated/expenses")({
  head: () => ({
    meta: [
      { title: "Расходы магазина — Do'kon CRM" },
      { name: "description", content: "Закуп товара, аренда, зарплата, транспорт — все траты магазина по дням." },
      { property: "og:title", content: "Расходы магазина — Do'kon CRM" },
      { property: "og:description", content: "Все траты магазина по категориям и дням." },
    ],
  }),
  component: () => <LedgerView mode="expenses" />,
});
