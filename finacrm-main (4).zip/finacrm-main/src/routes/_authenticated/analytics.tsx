import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";
import { StatCard, EmptyState } from "@/components/StatCard";
import { useI18n, type Key } from "@/lib/i18n";
import { formatMoney } from "@/lib/format";
import { useDebtEntries, useFinanceEntries, useProfile } from "@/lib/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({
    meta: [
      { title: "Аналитика магазина — Do'kon CRM" },
      { name: "description", content: "Динамика прибыли, структура расходов и рост долгов за неделю, месяц или год." },
      { property: "og:title", content: "Аналитика магазина — Do'kon CRM" },
      { property: "og:description", content: "Динамика прибыли и структура расходов магазина." },
    ],
  }),
  component: Analytics,
});

const RANGES: { value: number; key: Key }[] = [
  { value: 7, key: "week" },
  { value: 30, key: "month" },
  { value: 365, key: "year" },
];

const CATEGORY_KEYS: Record<string, Key> = {
  purchase: "catPurchase",
  rent: "catRent",
  salary: "catSalary",
  transport: "catTransport",
  other: "catOther",
};

const PIE_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Analytics() {
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: finance = [] } = useFinanceEntries();
  const { data: debts = [] } = useDebtEntries();
  const [days, setDays] = useState(30);

  const currency = profile?.currency ?? "UZS";
  const from = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - days + 1);
    return d.toISOString().slice(0, 10);
  }, [days]);

  const inRange = finance.filter((e) => e.entry_date >= from);

  const series = useMemo(() => {
    const map = new Map<string, { income: number; expense: number }>();
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      map.set(d.toISOString().slice(0, 10), { income: 0, expense: 0 });
    }
    for (const e of inRange) {
      const row = map.get(e.entry_date);
      if (!row) continue;
      if (e.kind === "income") row.income += e.amount;
      else row.expense += e.amount;
    }
    return [...map.entries()].map(([date, v]) => ({
      date: new Date(date).toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" }),
      ...v,
      profit: v.income - v.expense,
    }));
  }, [inRange, days]);

  const income = inRange.filter((e) => e.kind === "income").reduce((s, e) => s + e.amount, 0);
  const expense = inRange.filter((e) => e.kind === "expense").reduce((s, e) => s + e.amount, 0);
  const owed = debts.reduce((s, e) => s + (e.kind === "debt" ? e.amount : -e.amount), 0);

  const byCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of inRange.filter((x) => x.kind === "expense")) {
      map.set(e.category, (map.get(e.category) ?? 0) + e.amount);
    }
    return [...map.entries()]
      .map(([category, value]) => ({ name: t(CATEGORY_KEYS[category] ?? "catOther"), value }))
      .sort((a, b) => b.value - a.value);
  }, [inRange, t]);

  const hasData = inRange.length > 0;

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {RANGES.map((r) => (
          <button
            key={r.value}
            onClick={() => setDays(r.value)}
            className={cn(
              "flex-1 rounded-2xl border px-3 py-2.5 text-sm font-semibold transition-colors",
              days === r.value ? "border-transparent bg-primary text-primary-foreground" : "bg-card hover:bg-accent",
            )}
          >
            {t(r.key)}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <StatCard label={t("incomeTotal")} value={formatMoney(income, currency)} tone="success" />
        <StatCard label={t("expenseTotal")} value={formatMoney(expense, currency)} tone="danger" />
        <StatCard
          label={t("profit")}
          value={formatMoney(income - expense, currency)}
          tone={income - expense >= 0 ? "success" : "danger"}
        />
        <StatCard label={t("owedByClients")} value={formatMoney(owed, currency)} tone="danger" />
      </div>

      {!hasData ? (
        <EmptyState title={t("noData")} hint={t("noDataHint")} />
      ) : (
        <>
          <section className="rounded-2xl border bg-card p-4">
            <h2 className="mb-4 text-sm font-bold">{t("growth")}</h2>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={series} margin={{ left: 0, right: 0, top: 4, bottom: 0 }}>
                <defs>
                  <linearGradient id="g-profit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--success)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--success)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="date" tickLine={false} axisLine={false} fontSize={11} minTickGap={24} />
                <Tooltip
                  formatter={(v: number) => formatMoney(v, currency)}
                  contentStyle={{
                    borderRadius: 16,
                    border: "1px solid var(--border)",
                    background: "var(--card)",
                    color: "var(--card-foreground)",
                  }}
                />
                <Area type="monotone" dataKey="profit" stroke="var(--success)" strokeWidth={2} fill="url(#g-profit)" />
              </AreaChart>
            </ResponsiveContainer>
          </section>

          <section className="rounded-2xl border bg-card p-4">
            <h2 className="mb-4 text-sm font-bold">
              {t("incomeTotal")} / {t("expenseTotal")}
            </h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={series} margin={{ left: 0, right: 0, top: 4, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="date" tickLine={false} axisLine={false} fontSize={11} minTickGap={24} />
                <Tooltip
                  cursor={{ fill: "var(--muted)" }}
                  formatter={(v: number) => formatMoney(v, currency)}
                  contentStyle={{
                    borderRadius: 16,
                    border: "1px solid var(--border)",
                    background: "var(--card)",
                    color: "var(--card-foreground)",
                  }}
                />
                <Bar dataKey="income" fill="var(--success)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="expense" fill="var(--danger)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </section>

          {byCategory.length > 0 ? (
            <section className="rounded-2xl border bg-card p-4">
              <h2 className="mb-4 text-sm font-bold">{t("breakdown")}</h2>
              <div className="flex flex-col items-center gap-4 sm:flex-row">
                <ResponsiveContainer width="100%" height={180} className="max-w-[220px]">
                  <PieChart>
                    <Pie data={byCategory} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2}>
                      {byCategory.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(v: number) => formatMoney(v, currency)}
                      contentStyle={{
                        borderRadius: 16,
                        border: "1px solid var(--border)",
                        background: "var(--card)",
                        color: "var(--card-foreground)",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <ul className="w-full flex-1 space-y-2">
                  {byCategory.map((c, i) => (
                    <li key={c.name} className="flex items-center gap-2 text-sm">
                      <span
                        className="h-3 w-3 shrink-0 rounded-full"
                        style={{ background: PIE_COLORS[i % PIE_COLORS.length] }}
                      />
                      <span className="min-w-0 flex-1 truncate">{c.name}</span>
                      <span className="shrink-0 font-semibold">{formatMoney(c.value, currency)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </section>
          ) : null}
        </>
      )}
    </div>
  );
}
