import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/StatCard";
import { useI18n, type Key } from "@/lib/i18n";
import { formatMoney, formatDateTime } from "@/lib/format";
import { useCustomers, useDebtEntries, useFinanceEntries, useProfile } from "@/lib/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({
    meta: [
      { title: "История операций — Do'kon CRM" },
      { name: "description", content: "Единая лента всех операций магазина: долги, оплаты, доходы и расходы." },
      { property: "og:title", content: "История операций — Do'kon CRM" },
      { property: "og:description", content: "Все операции магазина в одной ленте." },
    ],
  }),
  component: History,
});

type Tab = "all" | "debt" | "income" | "expense";

function History() {
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: finance = [] } = useFinanceEntries();
  const { data: debts = [] } = useDebtEntries();
  const { data: customers = [] } = useCustomers();
  const [tab, setTab] = useState<Tab>("all");

  const currency = profile?.currency ?? "UZS";

  const items = useMemo(() => {
    const rows = [
      ...finance.map((e) => ({
        id: e.id,
        at: e.created_at,
        type: e.kind as Tab,
        title: e.kind === "income" ? t("income") : t("expense"),
        comment: e.comment,
        amount: e.amount,
        positive: e.kind === "income",
      })),
      ...debts.map((e) => ({
        id: e.id,
        at: e.created_at,
        type: "debt" as Tab,
        title:
          (e.kind === "debt" ? t("debt") : t("payment")) +
          " · " +
          (customers.find((c) => c.id === e.customer_id)?.name ?? ""),
        comment: e.comment,
        amount: e.amount,
        positive: e.kind === "payment",
      })),
    ].sort((a, b) => (a.at < b.at ? 1 : -1));
    return tab === "all" ? rows : rows.filter((r) => r.type === tab);
  }, [finance, debts, customers, tab, t]);

  const tabs: { value: Tab; key: Key }[] = [
    { value: "all", key: "all" },
    { value: "debt", key: "debts" },
    { value: "income", key: "income" },
    { value: "expense", key: "expense" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((x) => (
          <button
            key={x.value}
            onClick={() => setTab(x.value)}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors",
              tab === x.value ? "border-transparent bg-primary text-primary-foreground" : "bg-card hover:bg-accent",
            )}
          >
            {t(x.key)}
          </button>
        ))}
      </div>

      <p className="text-xs text-muted-foreground">
        {items.length} {t("entries")}
      </p>

      {items.length === 0 ? (
        <EmptyState title={t("noData")} hint={t("noDataHint")} />
      ) : (
        <ul className="divide-y overflow-hidden rounded-2xl border bg-card">
          {items.map((item) => (
            <li key={item.id} className="flex items-center gap-3 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{item.title}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {formatDateTime(item.at)}
                  {item.comment ? ` · ${item.comment}` : ""}
                </p>
              </div>
              <span className={cn("shrink-0 text-sm font-bold", item.positive ? "text-success" : "text-danger")}>
                {item.positive ? "+" : "−"}
                {formatMoney(item.amount, currency)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
