import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { TrendingUp, TrendingDown, PiggyBank, HandCoins, UserPlus, Wallet, Receipt, Plus } from "lucide-react";
import { StatCard, EmptyState } from "@/components/StatCard";
import { AmountDialog } from "@/components/AmountDialog";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { formatMoney, formatDateTime, today } from "@/lib/format";
import {
  EXPENSE_CATEGORIES,
  INCOME_CATEGORIES,
  useAddFinanceEntry,
  useDebtEntries,
  useCustomers,
  useFinanceEntries,
  useProfile,
} from "@/lib/data";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Главная — Do'kon CRM" },
      { name: "description", content: "Продажи, расходы, прибыль и долги вашего магазина за сегодня." },
      { property: "og:title", content: "Главная — Do'kon CRM" },
      { property: "og:description", content: "Продажи, расходы, прибыль и долги магазина за сегодня." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: finance = [] } = useFinanceEntries();
  const { data: debts = [] } = useDebtEntries();
  const { data: customers = [] } = useCustomers();
  const addFinance = useAddFinanceEntry();
  const [dialog, setDialog] = useState<null | "income" | "expense">(null);

  const currency = profile?.currency ?? "UZS";
  const d = today();

  const stats = useMemo(() => {
    const todayFinance = finance.filter((e) => e.entry_date === d);
    const sales = todayFinance.filter((e) => e.kind === "income").reduce((s, e) => s + e.amount, 0);
    const spent = todayFinance.filter((e) => e.kind === "expense").reduce((s, e) => s + e.amount, 0);
    const todayDebts = debts.filter((e) => e.entry_date === d);
    const received = todayDebts.filter((e) => e.kind === "payment").reduce((s, e) => s + e.amount, 0);
    const newDebt = todayDebts.filter((e) => e.kind === "debt").reduce((s, e) => s + e.amount, 0);
    const owed = debts.reduce((s, e) => s + (e.kind === "debt" ? e.amount : -e.amount), 0);
    return { sales, spent, profit: sales - spent, received, newDebt, owed };
  }, [finance, debts, d]);

  const feed = useMemo(() => {
    const items = [
      ...finance.map((e) => ({
        id: e.id,
        at: e.created_at,
        label: e.kind === "income" ? t("income") : t("expense"),
        amount: e.amount,
        positive: e.kind === "income",
        comment: e.comment,
      })),
      ...debts.map((e) => ({
        id: e.id,
        at: e.created_at,
        label:
          (e.kind === "debt" ? t("debt") : t("payment")) +
          " · " +
          (customers.find((c) => c.id === e.customer_id)?.name ?? ""),
        amount: e.amount,
        positive: e.kind === "payment",
        comment: e.comment,
      })),
    ];
    return items.sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 6);
  }, [finance, debts, customers, t]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          label={t("salesToday")}
          value={formatMoney(stats.sales, currency)}
          tone="success"
          icon={<TrendingUp className="h-4 w-4" />}
        />
        <StatCard
          label={t("expensesToday")}
          value={formatMoney(stats.spent, currency)}
          tone="danger"
          icon={<TrendingDown className="h-4 w-4" />}
        />
        <StatCard
          label={t("netProfit")}
          value={formatMoney(stats.profit, currency)}
          tone={stats.profit >= 0 ? "success" : "danger"}
          icon={<PiggyBank className="h-4 w-4" />}
        />
        <StatCard
          label={t("totalOwed")}
          value={formatMoney(stats.owed, currency)}
          tone="danger"
          icon={<HandCoins className="h-4 w-4" />}
          hint={`${t("debtsReceived")}: ${formatMoney(stats.received, currency)} · ${t("newDebts")}: ${formatMoney(stats.newDebt, currency)}`}
        />
      </div>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t("quickActions")}</h2>
        <div className="grid grid-cols-2 gap-3">
          <Button asChild className="h-16 justify-start gap-3 rounded-2xl bg-danger text-danger-foreground hover:bg-danger/90">
            <Link to="/debts">
              <UserPlus className="h-5 w-5" /> {t("addDebt")}
            </Link>
          </Button>
          <Button asChild variant="outline" className="h-16 justify-start gap-3 rounded-2xl">
            <Link to="/debts">
              <HandCoins className="h-5 w-5" /> {t("takePayment")}
            </Link>
          </Button>
          <Button
            className="h-16 justify-start gap-3 rounded-2xl bg-success text-success-foreground hover:bg-success/90"
            onClick={() => setDialog("income")}
          >
            <Wallet className="h-5 w-5" /> {t("addIncome")}
          </Button>
          <Button variant="outline" className="h-16 justify-start gap-3 rounded-2xl" onClick={() => setDialog("expense")}>
            <Receipt className="h-5 w-5" /> {t("addExpense")}
          </Button>
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t("history")}</h2>
          <Link to="/history" className="text-sm font-medium text-success">
            {t("allOperations")}
          </Link>
        </div>
        {feed.length === 0 ? (
          <EmptyState
            title={t("noData")}
            hint={t("noDataHint")}
            action={
              <Button className="h-12 rounded-2xl bg-success text-success-foreground hover:bg-success/90" onClick={() => setDialog("income")}>
                <Plus className="h-4 w-4" /> {t("addIncome")}
              </Button>
            }
          />
        ) : (
          <ul className="divide-y overflow-hidden rounded-2xl border bg-card">
            {feed.map((item) => (
              <li key={item.id} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{item.label}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {formatDateTime(item.at)}
                    {item.comment ? ` · ${item.comment}` : ""}
                  </p>
                </div>
                <p className={`shrink-0 text-sm font-bold ${item.positive ? "text-success" : "text-danger"}`}>
                  {item.positive ? "+" : "−"}
                  {formatMoney(item.amount, currency)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <AmountDialog
        open={dialog !== null}
        onOpenChange={(v) => setDialog(v ? dialog : null)}
        title={dialog === "expense" ? t("addExpense") : t("addIncome")}
        tone={dialog === "expense" ? "danger" : "success"}
        categories={dialog === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES}
        defaultCategory={dialog === "expense" ? "purchase" : "sales"}
        onSubmit={async (v) => {
          await addFinance.mutateAsync({ kind: dialog === "expense" ? "expense" : "income", ...v });
          toast.success(t("saved"));
        }}
      />
    </div>
  );
}
