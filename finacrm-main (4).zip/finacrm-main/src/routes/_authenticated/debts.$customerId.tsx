import { useMemo, useState } from "react";
import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { toast } from "sonner";
import { ArrowLeft, Plus, Check, Trash2 } from "lucide-react";
import { AmountDialog } from "@/components/AmountDialog";
import { EmptyState } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useI18n } from "@/lib/i18n";
import { formatMoney, formatDateTime } from "@/lib/format";
import {
  balanceOf,
  useAddDebtEntry,
  useCustomers,
  useDebtEntries,
  useDeleteEntry,
  useProfile,
} from "@/lib/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/debts/$customerId")({
  head: () => ({
    meta: [
      { title: "Долг клиента — Do'kon CRM" },
      { name: "description", content: "Текущий долг клиента, история операций и приём оплаты." },
      { property: "og:title", content: "Долг клиента — Do'kon CRM" },
      { property: "og:description", content: "Текущий долг клиента и история операций." },
    ],
  }),
  component: CustomerPage,
});

function CustomerPage() {
  const { customerId } = useParams({ from: "/_authenticated/debts/$customerId" });
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: customers = [] } = useCustomers();
  const { data: entries = [] } = useDebtEntries();
  const addEntry = useAddDebtEntry();
  const removeEntry = useDeleteEntry("debt_entries");
  const [dialog, setDialog] = useState<null | "debt" | "payment">(null);
  const [toDelete, setToDelete] = useState<string | null>(null);

  const currency = profile?.currency ?? "UZS";
  const customer = customers.find((c) => c.id === customerId);
  const balance = balanceOf(entries, customerId);
  const list = useMemo(() => entries.filter((e) => e.customer_id === customerId), [entries, customerId]);

  return (
    <div className="space-y-5">
      <Link to="/debts" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> {t("back")}
      </Link>

      <div className="rounded-3xl border bg-card p-5">
        <p className="text-lg font-extrabold tracking-tight">{customer?.name ?? "—"}</p>
        {customer?.phone ? <p className="text-sm text-muted-foreground">{customer.phone}</p> : null}
        {customer?.note ? <p className="mt-1 text-sm text-muted-foreground">{customer.note}</p> : null}
        <p className="mt-4 text-xs font-medium text-muted-foreground">{t("currentDebt")}</p>
        <p className={cn("text-3xl font-extrabold", balance > 0 ? "text-danger" : "text-success")}>
          {formatMoney(balance, currency)}
        </p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Button
            className="h-13 rounded-2xl bg-success py-3 font-semibold text-success-foreground hover:bg-success/90"
            onClick={() => setDialog("payment")}
            disabled={balance <= 0}
          >
            {t("takePayment")}
          </Button>
          <Button variant="outline" className="h-13 rounded-2xl py-3 font-semibold" onClick={() => setDialog("debt")}>
            <Plus className="h-4 w-4" /> {t("addMore")}
          </Button>
        </div>
        {balance > 0 ? (
          <Button
            variant="ghost"
            className="mt-2 h-12 w-full rounded-2xl text-success"
            onClick={async () => {
              await addEntry.mutateAsync({
                customer_id: customerId,
                kind: "payment",
                amount: balance,
                comment: t("paidFull"),
                entry_date: new Date().toISOString().slice(0, 10),
              });
              toast.success(t("saved"));
            }}
          >
            <Check className="h-4 w-4" /> {t("paidFull")}
          </Button>
        ) : null}
      </div>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-muted-foreground">{t("debtHistory")}</h2>
        {list.length === 0 ? (
          <EmptyState title={t("noData")} hint={t("noDataHint")} />
        ) : (
          <ul className="divide-y overflow-hidden rounded-2xl border bg-card">
            {list.map((e) => (
              <li key={e.id} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{e.kind === "debt" ? t("debt") : t("payment")}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {formatDateTime(e.created_at)}
                    {e.comment ? ` · ${e.comment}` : ""}
                  </p>
                </div>
                <span className={cn("shrink-0 text-sm font-bold", e.kind === "debt" ? "text-danger" : "text-success")}>
                  {e.kind === "debt" ? "+" : "−"}
                  {formatMoney(e.amount, currency)}
                </span>
                <button
                  onClick={() => setToDelete(e.id)}
                  className="shrink-0 text-muted-foreground hover:text-danger"
                  aria-label={t("delete")}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <AmountDialog
        open={dialog !== null}
        onOpenChange={(v) => setDialog(v ? dialog : null)}
        title={dialog === "payment" ? t("takePayment") : t("addDebt")}
        tone={dialog === "payment" ? "success" : "danger"}
        header={
          <div className="rounded-2xl bg-muted px-4 py-3">
            <p className="text-xs text-muted-foreground">{t("currentDebt")}</p>
            <p className="text-lg font-bold">{formatMoney(balance, currency)}</p>
          </div>
        }
        onSubmit={async (v) => {
          await addEntry.mutateAsync({
            customer_id: customerId,
            kind: dialog === "payment" ? "payment" : "debt",
            amount: v.amount,
            comment: v.comment,
            entry_date: v.entry_date,
          });
          toast.success(t("saved"));
        }}
      />

      <AlertDialog open={toDelete !== null} onOpenChange={(v) => !v && setToDelete(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>{t("confirmDelete")}</AlertDialogTitle>
            <AlertDialogDescription>{t("confirmDeleteText")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-2xl">{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="rounded-2xl bg-danger text-danger-foreground hover:bg-danger/90"
              onClick={async () => {
                if (toDelete) await removeEntry.mutateAsync(toDelete);
                setToDelete(null);
                toast.success(t("deleted"));
              }}
            >
              {t("delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
