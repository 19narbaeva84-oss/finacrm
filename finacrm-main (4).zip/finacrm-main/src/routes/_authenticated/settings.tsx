import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Download, LogOut, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n, type Lang } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { supabase } from "@/integrations/supabase/client";
import { useCustomers, useDebtEntries, useFinanceEntries, useProfile, useUpdateProfile } from "@/lib/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Настройки — Do'kon CRM" },
      { name: "description", content: "Название магазина, валюта, язык, тема оформления и экспорт данных." },
      { property: "og:title", content: "Настройки — Do'kon CRM" },
      { property: "og:description", content: "Магазин, валюта, язык, тема и экспорт данных." },
    ],
  }),
  component: Settings,
});

const CURRENCIES = ["UZS", "USD", "RUB", "KZT"];

function Settings() {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const update = useUpdateProfile();
  const { data: customers = [] } = useCustomers();
  const { data: debts = [] } = useDebtEntries();
  const { data: finance = [] } = useFinanceEntries();

  const [storeName, setStoreName] = useState("");
  const [fullName, setFullName] = useState("");

  useEffect(() => {
    if (profile) {
      setStoreName(profile.store_name ?? "");
      setFullName(profile.full_name ?? "");
    }
  }, [profile]);

  const exportCsv = () => {
    const rows: string[][] = [["type", "date", "name_or_category", "amount", "comment"]];
    for (const e of finance) {
      rows.push([e.kind, e.entry_date, e.category, String(e.amount), e.comment ?? ""]);
    }
    for (const e of debts) {
      rows.push([
        e.kind,
        e.entry_date,
        customers.find((c) => c.id === e.customer_id)?.name ?? "",
        String(e.amount),
        e.comment ?? "",
      ]);
    }
    const csv = rows.map((r) => r.map((v) => `"${v.replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `dokon-crm-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const save = async (patch: Parameters<typeof update.mutateAsync>[0]) => {
    await update.mutateAsync(patch);
    toast.success(t("saved"));
  };

  return (
    <div className="space-y-4">
      <section className="space-y-4 rounded-2xl border bg-card p-4">
        <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t("profile")}</h2>
        <div className="space-y-2">
          <Label htmlFor="store">{t("storeName")}</Label>
          <Input
            id="store"
            value={storeName}
            onChange={(e) => setStoreName(e.target.value)}
            onBlur={() => storeName && storeName !== profile?.store_name && save({ store_name: storeName })}
            className="h-12 rounded-2xl"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="fullname">{t("yourName")}</Label>
          <Input
            id="fullname"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            onBlur={() => fullName !== (profile?.full_name ?? "") && save({ full_name: fullName })}
            className="h-12 rounded-2xl"
          />
        </div>
        <div className="space-y-2">
          <Label>{t("currency")}</Label>
          <div className="flex flex-wrap gap-2">
            {CURRENCIES.map((c) => (
              <button
                key={c}
                onClick={() => save({ currency: c })}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                  profile?.currency === c ? "border-transparent bg-primary text-primary-foreground" : "hover:bg-accent",
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="space-y-4 rounded-2xl border bg-card p-4">
        <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t("settings")}</h2>
        <div className="space-y-2">
          <Label>{t("language")}</Label>
          <div className="flex gap-2">
            {(["ru", "uz"] as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => {
                  setLang(l);
                  update.mutate({ language: l });
                }}
                className={cn(
                  "flex-1 rounded-2xl border px-4 py-3 text-sm font-semibold transition-colors",
                  lang === l ? "border-transparent bg-primary text-primary-foreground" : "hover:bg-accent",
                )}
              >
                {l === "ru" ? "Русский" : "O'zbekcha"}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label>{t("theme")}</Label>
          <div className="flex gap-2">
            <button
              onClick={() => setTheme("light")}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold transition-colors",
                theme === "light" ? "border-transparent bg-primary text-primary-foreground" : "hover:bg-accent",
              )}
            >
              <Sun className="h-4 w-4" /> {t("light")}
            </button>
            <button
              onClick={() => setTheme("dark")}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold transition-colors",
                theme === "dark" ? "border-transparent bg-primary text-primary-foreground" : "hover:bg-accent",
              )}
            >
              <Moon className="h-4 w-4" /> {t("dark")}
            </button>
          </div>
        </div>
      </section>

      <Button variant="outline" className="h-14 w-full rounded-2xl text-base font-semibold" onClick={exportCsv}>
        <Download className="h-5 w-5" /> {t("exportData")}
      </Button>

      <Button
        variant="ghost"
        className="h-14 w-full rounded-2xl text-base font-semibold text-danger hover:bg-danger-soft hover:text-danger"
        onClick={async () => {
          await supabase.auth.signOut();
          navigate({ to: "/auth" });
        }}
      >
        <LogOut className="h-5 w-5" /> {t("signOut")}
      </Button>
    </div>
  );
}
