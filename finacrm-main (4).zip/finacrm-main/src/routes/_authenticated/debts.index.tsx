import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Plus, Search, ChevronRight } from "lucide-react";
import { EmptyState } from "@/components/StatCard";
import { AmountDialog } from "@/components/AmountDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useI18n } from "@/lib/i18n";
import { formatMoney, formatDate } from "@/lib/format";
import { balanceOf, useAddDebtEntry, useCustomers, useDebtEntries, useProfile, useSaveCustomer } from "@/lib/data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/debts/")({
  head: () => ({
    meta: [
      { title: "Долги клиентов — Do'kon CRM" },
      { name: "description", content: "Список должников, поиск по имени и телефону, приём оплаты в один клик." },
      { property: "og:title", content: "Долги клиентов — Do'kon CRM" },
      { property: "og:description", content: "Список должников и приём оплаты в один клик." },
    ],
  }),
  component: DebtsPage,
});

type Filter = "all" | "big" | "recent" | "closed";

function DebtsPage() {
  const { t } = useI18n();
  const { data: profile } = useProfile();
  const { data: customers = [] } = useCustomers();
  const { data: entries = [] } = useDebtEntries();
  const saveCustomer = useSaveCustomer();
  const addEntry = useAddDebtEntry();

  const currency = profile?.currency ?? "UZS";
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [createdId, setCreatedId] = useState<string | null>(null);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return customers
      .map((c) => ({ customer: c, balance: balanceOf(entries, c.id) }))
      .filter(({ customer, balance }) => {
        if (q && !(customer.name.toLowerCase().includes(q) || (customer.phone ?? "").includes(q))) return false;
        if (filter === "closed") return balance <= 0;
        if (filter === "big") return balance >= 500000;
        return balance > 0 || filter === "recent";
      })
      .sort((a, b) => (filter === "recent" ? (a.customer.updated_at < b.customer.updated_at ? 1 : -1) : b.balance - a.balance));
  }, [customers, entries, query, filter]);

  const total = rows.reduce((s, r) => s + Math.max(r.balance, 0), 0);

  const filters: { value: Filter; label: string }[] = [
    { value: "all", label: t("all") },
    { value: "big", label: t("bigDebts") },
    { value: "recent", label: t("recent") },
    { value: "closed", label: t("closed") },
  ];

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border bg-card p-4">
        <p className="text-xs font-medium text-muted-foreground">{t("totalOwed")}</p>
        <p className="mt-1 text-2xl font-extrabold text-danger">{formatMoney(total, currency)}</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("search")}
          className="h-12 rounded-2xl pl-9"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {filters.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={cn(
              "shrink-0 rounded-full border px-3 py-2 text-sm font-medium transition-colors",
              filter === f.value ? "border-transparent bg-primary text-primary-foreground" : "bg-card hover:bg-accent",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <Button
        className="h-14 w-full rounded-2xl bg-danger text-base font-semibold text-danger-foreground hover:bg-danger/90"
        onClick={() => {
          setName("");
          setPhone("");
          setNote("");
          setNewOpen(true);
        }}
      >
        <Plus className="h-5 w-5" /> {t("addDebt")}
      </Button>

      {rows.length === 0 ? (
        <EmptyState title={t("noDebts")} hint={t("noDebtsHint")} />
      ) : (
        <ul className="divide-y overflow-hidden rounded-2xl border bg-card">
          {rows.map(({ customer, balance }) => (
            <li key={customer.id}>
              <Link
                to="/debts/$customerId"
                params={{ customerId: customer.id }}
                className="flex items-center gap-3 px-4 py-3.5 transition-colors hover:bg-accent"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-muted text-sm font-bold">
                  {customer.name.slice(0, 1).toUpperCase()}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{customer.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {customer.phone ?? formatDate(customer.updated_at)}
                  </p>
                </div>
                <span className={cn("shrink-0 text-sm font-bold", balance > 0 ? "text-danger" : "text-success")}>
                  {formatMoney(balance, currency)}
                </span>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
              </Link>
            </li>
          ))}
        </ul>
      )}

      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="max-w-md rounded-3xl">
          <DialogHeader>
            <DialogTitle>{t("newCustomer")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">{t("customerName")}</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="h-12 rounded-2xl" autoFocus />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">
                {t("phone")} <span className="text-muted-foreground">({t("optional")})</span>
              </Label>
              <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="h-12 rounded-2xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="note">
                {t("note")} <span className="text-muted-foreground">({t("optional")})</span>
              </Label>
              <Textarea id="note" rows={2} value={note} onChange={(e) => setNote(e.target.value)} className="rounded-2xl" />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="ghost" className="h-12 rounded-2xl" onClick={() => setNewOpen(false)}>
              {t("cancel")}
            </Button>
            <Button
              className="h-12 flex-1 rounded-2xl bg-danger text-base font-semibold text-danger-foreground hover:bg-danger/90"
              disabled={!name.trim()}
              onClick={async () => {
                const id = await saveCustomer.mutateAsync({ name: name.trim(), phone, note });
                setNewOpen(false);
                setCreatedId(id);
              }}
            >
              {t("save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AmountDialog
        open={createdId !== null}
        onOpenChange={(v) => !v && setCreatedId(null)}
        title={t("addDebt")}
        tone="danger"
        onSubmit={async (v) => {
          if (!createdId) return;
          await addEntry.mutateAsync({
            customer_id: createdId,
            kind: "debt",
            amount: v.amount,
            comment: v.comment,
            entry_date: v.entry_date,
          });
          toast.success(t("saved"));
          setCreatedId(null);
        }}
      />
    </div>
  );
}
