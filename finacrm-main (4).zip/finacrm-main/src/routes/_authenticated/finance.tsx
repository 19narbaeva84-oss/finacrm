import { createFileRoute } from "@tanstack/react-router";
import { LedgerView } from "@/components/LedgerView";

export const Route = createFileRoute("/_authenticated/finance")({
  head: () => ({
    meta: [
      { title: "Финансы магазина — Do'kon CRM" },
      { name: "description", content: "Записывайте продажи и расходы частями в течение дня — итог считается сам." },
      { property: "og:title", content: "Финансы магазина — Do'kon CRM" },
      { property: "og:description", content: "Продажи и расходы по дням с автоматическим итогом." },
    ],
  }),
  component: () => <LedgerView mode="finance" />,
});
